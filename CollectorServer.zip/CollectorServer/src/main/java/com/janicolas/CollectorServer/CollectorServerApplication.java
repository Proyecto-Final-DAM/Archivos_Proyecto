package com.janicolas.CollectorServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollectorServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollectorServerApplication.class, args);
	}

}
